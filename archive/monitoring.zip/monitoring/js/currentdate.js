const currentDate = new Date().toString();
document.getElementById("currentDate").innerHTML = currentDate;

const currentYear = (new Date()).getFullYear().toString();
document.getElementById('currentYear').innerHTML = currentYear;